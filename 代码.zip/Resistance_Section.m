function Ans = Resistance_Section(A, Waterline)
    % 计算水下阻力截面面积（完全保留原始公式）
    % 输入参数（单位保持原样）:
    %   A - 船体形状系数 (无量纲)
    %   Waterline - 吃水线高度 (cm)
    % 输出:
    %   Ans - 水下阻力截面面积 (cm²)

    % ===== 参数验证 =====
    validateattributes(A, {'double'}, {'positive', 'scalar'});
    validateattributes(Waterline, {'double'}, {'positive', 'scalar'});

    % ===== 船体方程（完全保留原始公式） =====
    % 原方程：z_min = A*(0.2y)^6 （x=0截面）
    z_min = @(y) A * (0.2 * y).^6;  % 单位：cm

    % ===== 计算y积分范围 =====
    % 解方程 Waterline = A*(0.2y)^6
    y_max = fzero(@(y) z_min(y) - Waterline, [0, 10*Waterline]);

    % ===== 面积计算（原积分逻辑未改动） =====
    f_area = @(y, z) ones(size(y));  % 被积函数为1（面积微元）
    Ans = integral2(f_area, -y_max, y_max, z_min, Waterline, 'RelTol', 1e-6);
    
    % 单位验证确保输出为cm²
    assert(Ans > 0 && Ans < 1e6, '截面面积异常: %.2f cm²', Ans);
end