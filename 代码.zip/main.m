for H = 10:1:15  % 先增大步长调试
    disp(['Processing H=', num2str(H), 'cm']);
    
    for A = 0.1:0.1:1  % 调整步长
        % 调试输出
        fprintf('Testing H=%.1f, A=%.4f...', H, A);
        
        
        % 尺寸约束（调试阶段）
        if (2*Y_MAX > 50) || (2*Y_MAX < 20) || (2*X_MAX > 25) || (2*X_MAX < 5) || ...
           (X_MAX/Y_MAX < 1.5) || (X_MAX/Y_MAX > 3.0)
            fprintf('尺寸约束不满足\n');
            continue;
        end
        
        %  计算船体特性
        %Y = [-2*Y_MAX/3, -Y_MAX/3, 0, Y_MAX/3, 2*Y_MAX/3]; % 添加Y定义
        try
            % 1.%船体总分的质量
            M = Boat_Quality(A,  H);

            % 2.船体的重心高度（center of mass in z方向
            com_z = Boat_COM(A, H);%船体的重心高度（center of mass in z方向）
            
               % 2.1. 吃水线约束
               %吃水线不能超过船体总高的95%，防止船只沉没过深
               %吃水线不能低于船体总高的30%，确保不浮得太浅
               %吃水线深度不得低于重心高度的90%，保证稳定。
            waterline = Waterline(A, H);
            if (waterline > H*0.88) || (waterline < H*0.50) || (waterline < com_z*0.9)
                fprintf('吃水线约束不满足: wl=%.2f, com_z=%.2f\n', waterline, com_z);
                continue;
            end
            
            % 3. 计算水平时吃水情况
            c1 = Waterline(A, H);
            fprintf('水平吃水深度为%d',c1);

            % 4. 计算135°倾斜吃水情
            c2 = Waterline_135(A, H);
            fprintf('倾斜吃水深度为%d',c2);

            % 6. 计算浮心和复原力矩
            %%%%%%%%%cob = COB(A, H, X_MAX, c, Angle);
            %%%%%%%%%com = [0, 0, com_z];
            %%%%%%%%%RT = Recovery_Torque(com, cob, Angle, g, M);
            
            % 7. 数据存储
            boat.A(count) = A;
            boat.H(count) = H;
            % ...其余存储代码...
            
            fprintf('有效配置找到!\n');
            count = count + 1;
            
        catch ME
            fprintf('计算错误: %s\n', ME.message);
        end
    end
end