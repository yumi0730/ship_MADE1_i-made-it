% 原方程
z_original = (A * abs((0.33*(abs(y*b)-1)).^7 + 1) .* (x*b).^2 + A * (0.2*(y*b)).^6)/b;

% 变换后方程
z_transformed = H - z_original;

%%z = H - (A * abs((0.33*(abs(y*b)-1)).^7 + 1) .* (x*b).^2 + A * (0.2*(y*b)).^6)/b;