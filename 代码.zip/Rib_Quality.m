function total_rib_mass = Rib_Quality(A, H)
    % 计算肋骨质量（无参数验证）
    % 输入参数（单位保持原样）:
    %   A - 船体形状系数 (无量纲)
    %   Y - 肋骨y坐标数组 (1×5, cm)
    %   H - 吃水线高度 (cm)
    %   Density - 材料密度 (kg/cm³)
    % 输出:
    %   Ans - 肋骨质量数组 (1×5, kg)

    % ===== 初始化 =====
    Ans = zeros(1, 5);
    b =0.4;
    Y_MAX = (5/b) * (H*b / A)^(1/6);
    Y = [-2*Y_MAX/3, -Y_MAX/3, 0, Y_MAX/3, 2*Y_MAX/3];
    Density = 0.0001458;
    b =0.4;
    % ===== 船体方程 =====
    hull_eq_z = @(x, y)(A * abs((0.33*(abs(y_rand*b)-1)).^7 + 1) .* (x_rand*b).^2 + ...
    A * (0.2*(y_rand*b)).^6)/b;
    
    % ===== 逐肋骨计算 =====
    for i = 1:5
        y = Y(i);  % 当前肋骨y坐标(cm)
        
        % 1. 计算肋骨半宽X（原公式未改动）
        psi_y = abs((0.33*(abs(y*b)-1))^7 + 1);
        numerator = (H*b) - A*(0.2*y*b)^6;
        denominator = A * psi_y * b;
        X = sqrt(max(numerator / denominator, 0));  % 单位: cm

        % 2. 质量计算（原积分逻辑未改动）
        if X <= 1e-6
            Ans(i) = 0;
        else
            Z_min = @(x) hull_eq_z(x, y);
            f = @(x, z) Density * ones(size(x));  % 被积函数: kg/cm³
            Ans(i) = integral2(f, -X, X, Z_min, H);  % 单位: kg/cm³ * cm³ = kg
            total_rib_mass = sum(Ans); % 对5个肋骨的质量求和
        end
    end
end

