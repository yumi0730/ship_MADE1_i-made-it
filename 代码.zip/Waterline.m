function waterline = Waterline(A, H)
% 蒙特卡洛法计算吃水线高度（简化版）
% 输入参数:
%   A - 船体形状系数, H - 船高(cm)
% 输出:
%   waterline - 吃水线高度(cm)

    % 固定参数设置
    Water_density = 0.001;    % 水密度(kg/cm³)
    b = 0.4;                  % 缩放系数
    N = 1e6;                  % 采样点数
    tolerance = 0.001;        % 收敛容差
    
    % 计算船体总质量（简化公式）
    M = Boat_Quality(A, H); % 示例值，实际应根据A,H,b计算
    
    % 船体尺寸范围
    Y_MAX = (5/b) * (H*b / A)^(1/6);
    X_MAX = sqrt(H / (A*b));
    
    % 二分法初始化
    low = 0; high = H;
    waterline = NaN;
    
    % 蒙特卡洛计算
    for iter = 1:100
        mid = (low + high)/2;
        
        % 1. 生成随机点
        x_rand = X_MAX * (2*rand(N,1) - 1);
        y_rand = Y_MAX * (2*rand(N,1) - 1);
        z_rand = H * rand(N,1);
        
        % 2. 计算船体表面高度
        hull_z = (A * abs((0.33*(abs(y_rand*b)-1)).^7 + 1) .* (x_rand*b).^2 + ...
                 A * (0.2*(y_rand*b)).^6)/b;
        
        % 3. 统计有效点
        valid = (z_rand >= hull_z) & (z_rand <= mid);
        V = sum(valid)/N * (2*X_MAX)*(2*Y_MAX)*H;
        F = V * Water_density;
        
        % 4. 收敛判断
        rel_error = abs(F - M)/M;
        if rel_error < tolerance
            waterline = mid;
            fprintf('收敛于迭代%d: 水平吃水线=%.3fcm\n', iter, waterline);
            break;
        elseif F < M
            low = mid;
        else
            high = mid;
        end
    end
end
% % 可视化结果
% visualize_monte_carlo(A, H, b, waterline, X_MAX, Y_MAX);
% end
% 
% function visualize_monte_carlo(A, H, b, waterline, X_MAX, Y_MAX)
% % 蒙特卡洛结果可视化
% figure('Position', [100 100 1200 500]);
% 
% % 船体截面图
% subplot(1,2,1);
% [x,y] = meshgrid(linspace(-X_MAX,X_MAX,100), linspace(0,Y_MAX,100));
% z = (A * abs((0.33*(abs(y*b)-1)).^7 + 1) .* (x*b).^2 + A*(0.2*(y*b)).^6)/b;
% contourf(x, y, z, 20);
% hold on;
% line([-X_MAX X_MAX], [waterline waterline], 'Color','r', 'LineWidth',2);
% title(sprintf('船体截面轮廓 (吃水线=%.2fcm)',waterline));
% xlabel('x (cm)'); ylabel('z (cm)');
% colorbar; axis equal;

% 3D效果图
%subplot(1,2,2);
%N_show = 5000; % 显示点数
%x_show = X_MAX * (2*rand(N_show,1) - 1);
%y_show = Y_MAX * (2*rand(N_show,1) - 1);
%z_show = H * rand(N_show,1);
%hull_z = (A * abs((0.33*(abs(y_show*b)-1)).^7 + 1) .* (x_show*b).^2 + ...
         %A * (0.2*(y_show*b)).^6)/b;
%valid = (z_show >= hull_z) & (z_show <= waterline);

%scatter3(x_show(valid), y_show(valid), z_show(valid), 10, 'filled', 'MarkerFaceColor',[0.2 0.6 1]);
%hold on;
%scatter3(x_show(~valid), y_show(~valid), z_show(~valid), 5, 'filled', 'MarkerFaceAlpha',0.2);
%title('蒙特卡洛采样点分布');
%xlabel('x (cm)'); ylabel('y (cm)'); zlabel('z (cm)');
%view(30,30); grid on;
%end

