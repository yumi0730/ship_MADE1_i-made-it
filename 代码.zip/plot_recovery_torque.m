function plot_recovery_torque(A, H)
    % 绘制恢复力矩 vs 倾斜角度曲线（0-180度，1°步长）
    % 输入参数:
    %   A - 船体形状参数
    %   H - 船高参数
    
    % 获取船体参数
    COM = [0,0,Boat_COM(A, H)];  % 重心坐标 [x,y,z]
    M = Boat_Quality(A, H); % 船体质量
    
    % 生成角度序列（1°步长）
    angles = 0:1:180;
    torques = zeros(size(angles));
    
    % 预计算浮心坐标（每个角度单独计算）
    cob_points = zeros(length(angles), 3);
    for i = 1:length(angles)
        cob_points(i,:)  = COB(A, H, angles(i));
    end
    
    % 计算每个角度对应的恢复力矩
    for i = 1:length(angles)
        torques(i,:) = Recovery_Torque(COM, cob_points(i,:), angles(i));
        % 在调用前检查参数有效性
    end
    
    % 创建专业工程图表
    figure('Position', [100, 100, 800, 600]);
    plot(angles, torques, 'b-', 'LineWidth', 2.5, 'Color', [0, 0.4470, 0.7410]);
    grid on;
    hold on;
    
    % 标记关键特征点
    [max_torque, max_idx] = max(torques);
    [min_torque, min_idx] = min(torques);
    zero_cross = find(diff(sign(torques)) ~= 0);
    
    % 绘制特征点（带黑色边框）
    plot(angles(max_idx), max_torque, 'o', 'MarkerSize', 10, ...
        'MarkerFaceColor', 'r', 'MarkerEdgeColor', 'k');
    plot(angles(min_idx), min_torque, 'o', 'MarkerSize', 10, ...
        'MarkerFaceColor', 'g', 'MarkerEdgeColor', 'k');
    if ~isempty(zero_cross)
        plot(angles(zero_cross), torques(zero_cross), 'o', 'MarkerSize', 10, ...
            'MarkerFaceColor', 'k', 'MarkerEdgeColor', 'k');
    end
    
    % 图表标注
    title(sprintf('恢复力矩曲线\nA=%.2f, H=%.1f', A, H), ...
          'FontSize', 16, 'FontWeight', 'bold');
    xlabel('倾斜角度 (degree)', 'FontSize', 14);
    ylabel('恢复力矩 (N·m)', 'FontSize', 14);
    
    % 动态生成图例
    legend_text = {
        '恢复力矩', 
        sprintf('最大力矩: %.1f° (%.1f N·m)', angles(max_idx), max_torque), 
        sprintf('最小力矩: %.1f° (%.1f N·m)', angles(min_idx), min_torque)
    };
    if ~isempty(zero_cross)
        legend_text{end+1} = sprintf('零力矩点: %.1f°', angles(zero_cross(1)));
    end
    legend(legend_text, 'Location', 'best', 'FontSize', 10);
    
    % 智能调整Y轴范围
    y_margin = 0.1 * (max_torque - min_torque);
    ylim([min(torques)-y_margin, max(torques)+y_margin]);
    xlim([0 180]);
    
    % 添加物理参数表（使用最后一个浮心坐标作为参考）
    param_text = {
        sprintf('船体质量: %.1f kg', M),
        sprintf('重心高度: %.3f m', COM(3)),
        sprintf('平均浮心高度: %.3f m', mean(cob_points(:,3))),
        sprintf('初稳性高范围: %.3f~%.3f m', ...
            min(cob_points(:,3)-COM(3)), max(cob_points(:,3)-COM(3)))
    };
    annotation('textbox', [0.15, 0.65, 0.25, 0.2], ...
        'String', param_text, ...
        'FitBoxToText', 'on', ...
        'BackgroundColor', 'w', ...
        'EdgeColor', 'k', ...
        'FontSize', 10, ...
        'LineWidth', 1);
    
    % 添加参考线
    plot([0 180], [0 0], 'k--', 'LineWidth', 1);
    grid minor;
end

plot_recovery_torque(0.3, 11)

