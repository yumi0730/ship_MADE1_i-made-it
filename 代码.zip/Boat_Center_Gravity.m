function Ans = Boat_Center_Gravity(Z, M)
    % 计算整船重心高度（基于质量加权平均）
    % 输入:
    %   Z - 各组件重心Z坐标数组 (m)
    %   M - 各组件质量数组 (kg)
    % 输出:
    %   Ans - 整船重心Z坐标 (m)
    
    % 参数验证
    if length(Z) ~= length(M)
        error('输入数组长度不匹配');
    end
    
    % 初始化累加器
    total_mass = 0;
    weighted_z_sum = 0;
    
    % 计算加权平均
    for i = 1:length(Z)
        weighted_z_sum = weighted_z_sum + M(i) * Z(i);
        total_mass = total_mass + M(i);
    end
    
    % 返回重心坐标
    if total_mass <= 0
        error('总质量必须为正数');
    end
    Ans = weighted_z_sum / total_mass;
end
