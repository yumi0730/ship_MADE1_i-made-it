function Anscob = COB(A, H, angle)
    % 计算复合区域形心（完全展开版）
    % 输入参数:
    %   A, H: 抛物线参数 z = H - A*b*x^2
    %   angle: 直线倾斜角度（度）
    % 输出参数:
    %   Anscob: 整体形心坐标 [x, 0, z]
    
    % ===== 参数初始化 =====
    b = 0.4;
    k = tan(deg2rad(angle));             % 直线斜率
    c = Waterline_general(A, H, angle);  % 直线截距
    X_MAX = sqrt(H / (A*b));             % 抛物线与x轴交点（定义域右边界）
    x0 = -c/k;                           % 直线与x轴交点
    
    % ===== 步骤1：计算抛物线与直线的交点 =====
    coeff = [A*b, k, c - H];
    discriminant = k^2 - 4*A*b*(c-H);  % 判别式
    
    x_roots = roots(coeff);
    x_roots = sort(real(x_roots));  % 按实部排序
    x1 = x_roots(1);
    x2 = x_roots(2);
    
    % ===== 步骤2：区域划分与形心计算 =====
    % 情况1：x0在[x1, X_MAX]区间内
    if discriminant == 0
        if (-X_MAX < x0)&&(X1>x0)
        % 模式1：两个区域（D1: -c/k→x1, D2: x1→X_MAX）
        % --- 区域D1 ---
        area_D1 = integral(@(x) H - A*b*x.^2, -c/k, x1);
        x_moment_D1 = integral(@(x) x.*(H - A*b*x.^2), -c/k, x1);
        z_moment_D1 = integral(@(x) (H - A*b*x.^2).^2/2, -c/k, x1);
        
        % D2: [x0, X_MAX] - 下边界x轴，上边界抛物线
        area_D2 = integral(@(x) H - A*b*x.^2, x0, X_MAX);
        x_moment_D2 = integral(@(x) x.*(H - A*b*x.^2), x0, X_MAX);
        z_moment_D2 = integral(@(x) (H - A*b*x.^2).^2/2, x0, X_MAX);

            % ===== 合并结果 =====
        total_area = area_D1 + area_D2;
        total_centroid_x = (x_moment_D1 + x_moment_D2) / total_area;
        total_centroid_z = (z_moment_D1 + z_moment_D2) / total_area;
    
        end
    % 情况2：
        elseif x0 > x1 && x0 <= X_MAX
        % --- 模式1：两个区域 ---
        % D1: [x1, x0] - 下边界直线，上边界抛物线
        area_D1 = integral(@(x) (H - A*b*x.^2) - (k*x + c), x1, x0 );
        x_moment_D1 = integral(@(x) x.*((H - A*b*x.^2) - (k*x + c)), x1, x0);
        z_moment_D1 = integral(@(x) ((H - A*b*x.^2).^2 - (k*x + c).^2)/2, x1, x0);
        
        % D2: [x0, X_MAX] - 下边界x轴，上边界抛物线
        area_D2 = integral(@(x) H - A*b*x.^2, x0, X_MAX);
        x_moment_D2 = integral(@(x) x.*(H - A*b*x.^2), x0, X_MAX);
        z_moment_D2 = integral(@(x) (H - A*b*x.^2).^2/2, x0, X_MAX);

        total_area = area_D1 + area_D2;
        total_centroid_x = (x_moment_D1 + x_moment_D2) / total_area;
        total_centroid_z = (z_moment_D1 + z_moment_D2) / total_area;
        % 情况2：
    elseif discriminant > 0
        if (x0 <-X_MAX )
        % 模式1：三个区域（D1: -X_MAX→x1, D2: x1→x2, D3: x2→X_MAX）
        % --- 区域D1 ---
        area_D1 = integral(@(x) H - A*b*x.^2, -X_MAX, x1);
        x_moment_D1 = integral(@(x) x.*(H - A*b*x.^2), -X_MAX, x1);
        z_moment_D1 = integral(@(x) (H - A*b*x.^2).^2/2, -X_MAX, x1);
        
        % D2: x1→x2
        area_D2 = integral(@(x) kx + b, x1, x2);
        x_moment_D2 = integral(@(x) x.*(kx + b), x1, x2);
        z_moment_D2 = integral(@(x) (kx + b).^2/2, x1, x2);

         % D3: x2→X_MAX
        area_D3 = integral(@(x) H - A*b*x.^2, x2, X_MAX);
        x_moment_D3 = integral(@(x) x.*(H - A*b*x.^2), x2, X_MAX);
        z_moment_D3 = integral(@(x) (H - A*b*x.^2).^2/2, x2, X_MAX);

        total_area = area_D1 + area_D2 + area_D3;
        total_centroid_x = (x_moment_D1 + x_moment_D2 + x_moment_D3) / total_area;
        total_centroid_z = (z_moment_D1 + z_moment_D2 + z_moment_D3) / total_area;
        end

    % 情况2：
        elseif (x0 > X_MAX )
        % --- 一个区域 ---
        % D1: [x1, x2] - 下边界直线，上边界抛物线
        area_D1 = integral(@(x) (H - A*b*x.^2) - (k*x + c), x0, X_MAX );
        x_moment_D1 = integral(@(x) x.*((H - A*b*x.^2) - (k*x + c)), x0, X_MAX);
        z_moment_D1 = integral(@(x) ((H - A*b*x.^2).^2 - (k*x + c).^2)/2, x0, X_MAX);

        total_area = area_D1 ;
       total_centroid_x = (x_moment_D1 ) / total_area;
       total_centroid_z = (z_moment_D1 ) / total_area;
          
    % 异常情况处理
    else
        error('交点位置异常: x0=%.2f, x1=%.2f, X_MAX=%.2f', x0, x1, X_MAX);
    end
    
    % ===== 合并结果 =====

    Anscob = [total_centroid_x, 0, total_centroid_z];
end