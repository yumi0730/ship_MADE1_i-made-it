function waterline1 = Waterline1_135(A ,H )
% 参数设置
b = 0.4;               % 船体缩放系数               
angle = 0;           % 水面倾斜角度(度)
water_density = 0.001; % 水密度(kg/cm³)
target_mass = Boat_Quality(A, H);    % 目标质量(1500g)
N = 1e6;               % 蒙特卡洛采样点数
tolerance = 1;        % 容许误差(cm³)
max_iter = 1000;       % 最大迭代次数

% 计算目标体积
target_volume = target_mass / water_density;

% 计算船体边界
Y_MAX = (5/b) * (H*b / A)^(1/6);
X_MAX = sqrt(H / (A*b));

% 生成随机点
rng(0);
x_rand = -X_MAX + 2*X_MAX * rand(N,1);
y_rand = -Y_MAX + 2*Y_MAX * rand(N,1);

% 计算船体表面高度
hull_z = H - ((A * abs((0.33*(abs(y_rand*b)-1)).^7 + 1) .* (x_rand*b).^2 + ...
    A * (0.2*(y_rand*b)).^6)/b);

% 水面斜率
k = abs(tan(deg2rad(angle)));

% 二分查找c_mid1
c_low = 0;
c_high = H;

fprintf('开始二分法搜索，目标体积: %.4f cm³\n', target_volume);
fprintf('迭代\t水线位置\t浸入体积\t差值\t\t误差\n');

for iter = 1:max_iter
    c_mid1 = (c_low + c_high)/2;
    water_z = k * x_rand + c_mid1;

    % 浸入区域判断 (三曲面围成)
    underwater = (water_z >= 0) & (hull_z <= water_z) & (hull_z >= 0);

    % 计算当前浸入体积
    immersed_volume = sum(underwater)/N * (2*X_MAX * 2*Y_MAX * H);
    volume_diff = immersed_volume - target_volume;
    
    % 打印当前迭代信息
    fprintf('%d\t%.4f\t%.4f\t%.4f\t%.4f\n', ...
        iter, c_mid1, immersed_volume, volume_diff, abs(volume_diff));

    % 收敛判断
    if abs(volume_diff) <= tolerance
        waterline1 = c_mid1;
        fprintf('\n找到解: c_mid1=%.4fcm 体积=%.4fcm³ (误差%.4fcm³)\n',...
            waterline1, immersed_volume, volume_diff);
        return;
    end
    
    % 更新二分法边界
    if volume_diff > 0
        c_high = c_mid1;
    else
        c_low = c_mid1;
    end
end

error('达到最大迭代次数仍未收敛');
end






   
