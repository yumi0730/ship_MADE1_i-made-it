function Ans = Boat_COM(A, H)
    % 计算船体重心高度
    % 输入:
    %   A - 船体形状系数
    %   H - 船体最大高度(cm)
    %   Density - 材料密度(kg/cm³)
    % 输出:
    %   Ans - 船体重心高度(cm)

    % 获取质量
    M_rib_mid = Rib_Quality(A, H);
    M_keel = Keel_Quality(A, H);
    M_mast = 0.1062;
    M_weight = 0.8758;

    % 计算肋骨重心
    Z_rib = Rib_Center_Gravity_Z(A, H);  % 肋骨重心Z坐标(m)

    
    % 计算龙骨重心
    Z_keel = Keel_Center_Gravity(A, H);  % 龙骨重心Z坐标(m)
    
    % 固定组件参数（桅杆和重物）
    Z_mast = 28.8;    % 桅杆重心(cm)2
    Z_weight = 3.8;  % 重物重心(cm)
    
    % 合并所有组件
    Z_arr = [Z_rib, Z_keel, Z_mast, Z_weight];
    M_arr = [ M_rib_mid, M_keel, M_mast, M_weight];
    % 计算整体重心（质量加权平均）
    M_total = Boat_Quality(A, H);
    Ans = sum(Z_arr .* M_arr) / M_total;  % (kg·m / kg) → 单位：m
end


