function Ans = Keel_Center_Gravity(A, H)
   %% 计算龙骨重心的Z坐标（cm）
    % 需要参数：
    % Y_MAX：龙骨长度的1/2（cm）
    % H：最大高度（cm）
    % Density：密度（kg/cm³）
    b =0.4;
    Y_MAX = (5/b) * (H*b / A)^(1/6);
    Density = 0.0001458;


    % 获取龙骨质量（直接调用Keel_Quality）
    M = Keel_Quality(A, H);
    
    % 龙骨曲线方程
    z =@(y) A * (b^5)*(0.2 * y).^6; 
    
    % 计算质量矩 a = ∬ρ*z dydz
    f = @(y, z) Density .* z;
    a = integral2(f, -Y_MAX, Y_MAX, z, H);
    

    % 计算重心高度（单位: kg·cm / kg = cm）
    Ans = a / M;
end