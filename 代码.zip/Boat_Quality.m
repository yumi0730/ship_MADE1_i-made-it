function Boat_Quality = Boat_Quality(A, H)

    M_rib = Rib_Quality(A, H);  % 单位kg
    
    % 2. 计算龙骨质量（直接调用Keel_Quality）
    M_keel = Keel_Quality(A, H);  % 单位kg
    
    % 3. 固定组件质量
    M_mast = 0.1062;    % 桅杆质量(kg)
    M_weight = 0.8758;  % 重物质量(kg)
    
    % 4. 总质量计算
    Boat_Quality = sum(M_rib) + M_keel + M_mast + M_weight;  % 单位kg
end