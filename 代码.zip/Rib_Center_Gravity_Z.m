function Ans = Rib_Center_Gravity_Z(A,  H)
    % 计算肋骨Z轴重心（仅计算中间对称肋骨）
    %   A - 船体形状系数 (无量纲)
    %   Y - 肋骨y坐标数组 (1×5, cm)，只使用Y(3)
    %   H - 肋骨最大高度
    %   Density - 材料密度 (kg/cm³)
    % 输出:
    %   Ans - 肋骨重心Z坐标（仅中间肋骨的值）
    
    % ===== 仅计算中间肋骨（第3个） =====

    b =0.4;
    y = 0;  % 当前肋骨y坐标(cm)
    Density = 0.0001458;

    % ===== 船体方程 =======
    hull_eq_z = @(x, y) (A * abs((0.33*(abs(y*b)-1))^7 + 1) .* (x*b).^2 + A * (0.2*(y*b)).^6)/b;
    
   % 1. 计算肋骨半宽X
    psi_y = abs((0.33*(abs(y*b)-1))^7 + 1);
    numerator = H - A*(0.2*(y*b)).^6/b;  
    denominator = A * b * psi_y;          
    
    if denominator <= eps
        X = 0;
    else
        X = sqrt(max(numerator / denominator, 0));  %取正，cm单位
    end

    % 2. 质量矩计算
    if X <= eps
        a = 0;
    else
        % 定义积分函数
        Z_min = @(x) hull_eq_z(x, y);
        f_moment = @(x, z) Density * z;  % 质量矩密度：ρ*z (kg/cm³ * cm)
        
        % 执行二重积分（单位: (kg/cm³)*cm * cm² = kg·cm）
        a = integral2(f_moment, -X, X, Z_min, H, 'RelTol', 1e-6);
    end

    % ===== 计算重心 =====
    % 仅计算中间肋骨的质量
    M = Rib_Quality(A,H);  % 质量(kg)
    
    % 计算重心坐标（单位: kg·cm / kg = cm）
    Ans = a / max(M, eps);  % 避免除零
end