function result = Keel_Quality( A,H)
    % 计算龙骨质量（基于船体方程）单位kg
    % 输入:
    %   Y_MAX - 龙骨y坐标范围（对称）
    %   H - 吃水线高度
    %   A - 船体形状系数
    %   Density - 材料密度（kg/m³）
    % 输出:
    %   Ans - 龙骨质量
    b =0.4;
    Y_MAX = (5/b) * (H*b / A)^(1/6);
    Density = 0.0001458;
    b =0.4;
    % 定义龙骨下表面（假设龙骨位于x=0处，即船体中心线）
    keel_Z = @(y) A * (b^5)*(0.2 * y).^6;  % z_min = A*(0.2y)^6 （x=0时）

    % 定义被积函数（质量密度）
    f = @(y, z) Density + y.*0 + z.*0;  % 常数密度

    %计算挖去部分的质量
       %矩形部分
      length_x = 8.8;
      width_y = 2.56;
      mass_rectangle = integral2(f, 0, length_x, 0, width_y);
      
      %总共挖去的质量
      dig = integral2(f, -17.5, 17.5, keel_Z, 5.65) + mass_rectangle;

    % 计算质量 Ans = ρ × 体积
    result = integral2(f, -Y_MAX, Y_MAX, keel_Z, H) - dig;
    
    
end