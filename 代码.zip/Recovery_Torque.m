function Ans = Recovery_Torque(A,H,COM, COB, Angle)
    % 计算船体恢复力矩（基于新船体方程）
    % 输入:
    %   COM - 重心坐标 [x, y, z] (m)
    %   COB - 浮心坐标 [x, y, z] (m)
    %   Angle - 倾斜角度 (deg)
    %   g - 重力加速度 (m/s²)
    %   M - 船体质量 (kg)
    % 输出:
    %   Ans - 恢复力矩 (N·m)
    g = 9.8;
    M = Boat_Quality(A, H); % 船体质量
    % 转换为弧度（270°为基准）
    angle_rad = (Angle - 270) / 180 * pi;
    
    % 计算重力方向向量（x和z方向）
    F = [g * M * cos(angle_rad), 0, g * M * sin(angle_rad)];
    
    % 计算力臂向量（浮心到重心的向量）
    r = COB - COM;
    
    % 计算力矩（叉积）
    RT = cross(r, F);
    
    % 返回y轴力矩分量（绕纵摇轴的恢复力矩）
     Ans = RT(2);  % 绕Y轴的力矩 (N·cm)
end
